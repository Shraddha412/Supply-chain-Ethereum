'use strict';

/**
 * This is a Node.JS application to request to create a New Company on the Network
 */

const helper = require('./contractHelper');
async function main(companyCRN, name, location, org) {

	try {
		console.log (companyCRN);
		const contract = await helper.getContractInstance();

		console.log('.....Requesting to create a New Company on the Network');
		const newCompanyBuffer = await contract.submitTransaction('registerCompany', companyCRN, name, location, org);
		
		// process response
		console.log('.....Processing New Company Transaction Response \n\n');
		let newCompany = JSON.parse(newCompanyBuffer.toString());
		console.log(newCompany);
		console.log('\n\n..... New Company Transaction Complete!');
		return newCompany;

	} catch (error) {

		console.log(`\n\n ${error} \n\n`);
		throw new Error(error);

	} finally {

		// Disconnect from the fabric gateway
		helper.disconnect();

	}
}




let args = process.argv.slice(2);
let companyCRN = args[0].toString();
let name = args[1].toString();
let location = args[2].toString();
let org = args[3].toString();
main(companyCRN, name, location, org).then(() => {
	console.log('New Company registered on the Network');
});

module.exports.execute = main;
