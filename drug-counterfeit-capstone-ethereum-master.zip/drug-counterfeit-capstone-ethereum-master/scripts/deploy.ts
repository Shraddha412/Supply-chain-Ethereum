import { ethers } from "hardhat";

async function main() {
  const PharmaNetContract = await ethers.getContractFactory("PharmaNet");
  const pharmanet = await PharmaNetContract.deploy();

  await pharmanet.deployed();

  console.log(`PharmaNet Smart Contract deployed to Network`);
}

// We recommend this pattern to be able to use async/await everywhere
// and properly handle errors.
main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
