# Pharma Network

An ethereum smart contract solution to demonstrate supply chain tracking of pharma drugs

1. Write Ethereum Smart Contract
2. Compile and Deploy using Hardhat
```shell
npx hardhat compile
npx hardhat node
npx hardhat run scripts/deploy.ts
```
3. Connect to smart contract using web3.js from a Node.js based backend.
